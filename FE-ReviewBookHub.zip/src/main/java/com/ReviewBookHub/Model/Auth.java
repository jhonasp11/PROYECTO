
package com.ReviewBookHub.Model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Auth {
    
    private String usuario;    
    private String contrasena;

}
