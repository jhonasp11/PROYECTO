
package com.ReviewBookHub.Entity;

import lombok.Data;

@Data
public class Auth {
    
    private String usuario;
    
    private String contrasena;

}
