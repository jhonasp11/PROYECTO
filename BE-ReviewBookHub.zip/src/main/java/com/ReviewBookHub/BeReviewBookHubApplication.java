package com.ReviewBookHub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeReviewBookHubApplication {

    public static void main(String[] args) {
        SpringApplication.run(BeReviewBookHubApplication.class, args);
    }

}

//http://localhost:8080/swagger-ui/index.html