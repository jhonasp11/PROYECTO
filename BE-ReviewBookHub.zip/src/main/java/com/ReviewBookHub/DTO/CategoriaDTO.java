
package com.ReviewBookHub.DTO;

import lombok.Data;

@Data
public class CategoriaDTO {
    
    private Long id;
    private String categoria;
    
}
